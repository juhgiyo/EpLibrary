/*! 
@file epMemory.h
@author Woong Gyu La a.k.a Chris. <juhgiyo@gmail.com>
@date April 16, 2011
@brief A Memory Dependencies Interface
@version 2.0

@section LICENSE

Copyright (C) 2012  Woong Gyu La <juhgiyo@gmail.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

@section DESCRIPTION

An Interface for Memory Dependencies.

*/

#ifndef __EP_MEMORY_H__
#define __EP_MEMORY_H__

#define EP_Malloc  malloc
#define EP_Realloc realloc
#define EP_Free    free
#define EP_NEW     new
#define EP_DELETE  delete

#endif //__EP_MEMORY_H__